// ─────────────────────────────────────────────
// CommodEx Backend — Node.js + Express + SQLite
// Deploy to Railway: railway.app
// ─────────────────────────────────────────────

const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'commodex-secret-change-in-production';
const DB_PATH = process.env.DB_PATH || './commodex.db';

// ── MIDDLEWARE ──
app.use(cors());
app.use(express.json());
app.use(express.static('public')); // serves your HTML files

// ── DATABASE SETUP ──
const db = new Database(DB_PATH);

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    company TEXT,
    country TEXT,
    phone TEXT,
    role TEXT NOT NULL DEFAULT 'buyer',
    kyc_status TEXT DEFAULT 'pending',
    is_active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    name_ar TEXT,
    icon TEXT DEFAULT '📦',
    status TEXT DEFAULT 'active',
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category_id INTEGER REFERENCES categories(id),
    name TEXT NOT NULL,
    grade TEXT,
    origin TEXT,
    unit TEXT DEFAULT 'Ton',
    min_price REAL NOT NULL,
    max_price REAL NOT NULL,
    certifications TEXT,
    status TEXT DEFAULT 'active',
    created_by INTEGER REFERENCES users(id),
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS negotiations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER REFERENCES products(id),
    buyer_agent TEXT,
    seller_agent TEXT,
    quantity REAL,
    opening_buyer REAL,
    opening_seller REAL,
    final_price REAL,
    rounds INTEGER DEFAULT 0,
    status TEXT DEFAULT 'active',
    incoterm TEXT DEFAULT 'FOB',
    payment_terms TEXT DEFAULT 'LC at sight',
    created_by INTEGER REFERENCES users(id),
    closed_at TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS deals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    negotiation_id INTEGER REFERENCES negotiations(id),
    reference TEXT UNIQUE NOT NULL,
    commodity TEXT NOT NULL,
    grade TEXT,
    quantity REAL,
    final_price REAL,
    total_value REAL,
    incoterm TEXT,
    payment_terms TEXT,
    platform_fee REAL,
    seller_receives REAL,
    status TEXT DEFAULT 'confirmed',
    buyer_id INTEGER REFERENCES users(id),
    seller_id INTEGER REFERENCES users(id),
    confirmed_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    deal_id INTEGER REFERENCES deals(id),
    stripe_txn_id TEXT,
    amount REAL NOT NULL,
    currency TEXT DEFAULT 'USD',
    method TEXT,
    status TEXT DEFAULT 'pending',
    paid_at TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
`);

// ── SEED DATA ──
const catCount = db.prepare('SELECT COUNT(*) as c FROM categories').get().c;
if (catCount === 0) {
  const insertCat = db.prepare('INSERT INTO categories (name, name_ar, icon) VALUES (?, ?, ?)');
  [
    ['Cement', 'أسمنت', '🏗️'],
    ['Steel', 'فولاذ', '⚙️'],
    ['PP Granules', 'حبيبات البولي بروبيلين', '🧪'],
    ['Urea', 'يوريا', '🌿'],
  ].forEach(r => insertCat.run(...r));

  const insertProd = db.prepare(`INSERT INTO products (category_id, name, grade, origin, unit, min_price, max_price, certifications) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
  [
    [1, 'Portland Cement', 'OPC 52.5 N', 'Saudi Arabia', 'Ton', 55, 72, 'ISO 9001, SASO, EN 197-1'],
    [1, 'Portland Cement', 'OPC 42.5 N', 'UAE', 'Ton', 48, 65, 'ISO 9001, SASO'],
    [2, 'Steel Rebar', 'ASTM A615 Grade 60', 'KSA (Jubail)', 'Ton', 480, 540, 'ISO 9001, Mill Cert, SASO'],
    [2, 'Steel Rebar', 'BS 4449 B500B', 'UAE (ICAD)', 'Ton', 490, 555, 'CE mark, Mill Cert'],
    [2, 'Steel HR Coil', 'SS400 / A36', 'Turkey', 'Ton', 510, 580, 'ISO 9001'],
    [3, 'PP Granules', 'Homo H030SG', 'Kuwait', 'Ton', 920, 1050, 'ISO 9001, COA, REACH'],
    [3, 'PP Granules', 'Copo BJ368MO', 'Saudi Arabia', 'Ton', 960, 1080, 'ISO 9001, COA'],
    [4, 'Urea', '46% N Prilled', 'Egypt', 'Ton', 310, 370, 'SGS cert, COO Egypt'],
    [4, 'Urea', '46% N Granular', 'Qatar', 'Ton', 325, 385, 'SGS cert, COO Qatar'],
  ].forEach(r => insertProd.run(...r));

  // Seed demo users
  const insertUser = db.prepare(`INSERT OR IGNORE INTO users (first_name, last_name, email, password_hash, company, country, role, kyc_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
  const hash = bcrypt.hashSync('Demo1234!', 10);
  insertUser.run('Ahmed', 'Al-Mansour', 'buyer@commodex.trade', hash, 'Al-Mansour Trading', 'Iraq', 'buyer', 'verified');
  insertUser.run('Hadeed', 'Admin', 'seller@commodex.trade', hash, 'Hadeed Steel', 'Saudi Arabia', 'seller', 'verified');
  insertUser.run('Platform', 'Admin', 'admin@commodex.trade', hash, 'ME-Global', 'UAE', 'admin', 'verified');

  console.log('✅ Database seeded.');
}

// ── AUTH MIDDLEWARE ──
function auth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch { res.status(401).json({ error: 'Invalid token' }); }
}

function adminOnly(req, res, next) {
  if (req.user?.role !== 'admin') return res.status(403).json({ error: 'Admin only' });
  next();
}

// ─────────────────────────────────────────────
// ── AUTH ROUTES ──
// ─────────────────────────────────────────────

// POST /api/auth/register
app.post('/api/auth/register', (req, res) => {
  const { first_name, last_name, email, password, company, country, phone, role } = req.body;
  if (!first_name || !email || !password) return res.status(400).json({ error: 'Missing required fields' });
  if (password.length < 8) return res.status(400).json({ error: 'Password too short' });
  const validRoles = ['buyer', 'seller', 'admin'];
  const userRole = validRoles.includes(role) ? role : 'buyer';
  try {
    const hash = bcrypt.hashSync(password, 10);
    const result = db.prepare(`INSERT INTO users (first_name, last_name, email, password_hash, company, country, phone, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`).run(first_name, last_name, email, hash, company, country, phone, userRole);
    const user = db.prepare('SELECT id, first_name, last_name, email, role, company, country, kyc_status FROM users WHERE id = ?').get(result.lastInsertRowid);
    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user });
  } catch (e) {
    if (e.message.includes('UNIQUE')) return res.status(409).json({ error: 'Email already registered' });
    res.status(500).json({ error: e.message });
  }
});

// POST /api/auth/login
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE email = ? AND is_active = 1').get(email);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
  const { password_hash, ...safeUser } = user;
  res.json({ token, user: safeUser });
});

// GET /api/auth/me
app.get('/api/auth/me', auth, (req, res) => {
  const user = db.prepare('SELECT id, first_name, last_name, email, role, company, country, phone, kyc_status, created_at FROM users WHERE id = ?').get(req.user.id);
  res.json(user);
});

// ─────────────────────────────────────────────
// ── CATEGORIES ──
// ─────────────────────────────────────────────

app.get('/api/categories', (req, res) => {
  const cats = db.prepare('SELECT c.*, COUNT(p.id) as product_count FROM categories c LEFT JOIN products p ON p.category_id = c.id GROUP BY c.id').all();
  res.json(cats);
});

app.post('/api/categories', auth, adminOnly, (req, res) => {
  const { name, name_ar, icon } = req.body;
  if (!name) return res.status(400).json({ error: 'Name required' });
  const result = db.prepare('INSERT INTO categories (name, name_ar, icon) VALUES (?, ?, ?)').run(name, name_ar || '', icon || '📦');
  res.json(db.prepare('SELECT * FROM categories WHERE id = ?').get(result.lastInsertRowid));
});

app.patch('/api/categories/:id', auth, adminOnly, (req, res) => {
  const { name, name_ar, icon, status } = req.body;
  db.prepare('UPDATE categories SET name=COALESCE(?,name), name_ar=COALESCE(?,name_ar), icon=COALESCE(?,icon), status=COALESCE(?,status) WHERE id=?').run(name, name_ar, icon, status, req.params.id);
  res.json(db.prepare('SELECT * FROM categories WHERE id = ?').get(req.params.id));
});

app.delete('/api/categories/:id', auth, adminOnly, (req, res) => {
  db.prepare('UPDATE categories SET status = ? WHERE id = ?').run('suspended', req.params.id);
  res.json({ ok: true });
});

// ─────────────────────────────────────────────
// ── PRODUCTS ──
// ─────────────────────────────────────────────

app.get('/api/products', (req, res) => {
  let q = 'SELECT p.*, c.name as category_name, c.name_ar as category_name_ar, c.icon as category_icon FROM products p JOIN categories c ON p.category_id = c.id WHERE 1=1';
  const params = [];
  if (req.query.category) { q += ' AND c.name = ?'; params.push(req.query.category); }
  if (req.query.status) { q += ' AND p.status = ?'; params.push(req.query.status); }
  if (req.query.origin) { q += ' AND p.origin LIKE ?'; params.push('%' + req.query.origin + '%'); }
  res.json(db.prepare(q).all(...params));
});

app.get('/api/products/:id', (req, res) => {
  const p = db.prepare('SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id WHERE p.id = ?').get(req.params.id);
  if (!p) return res.status(404).json({ error: 'Product not found' });
  res.json(p);
});

app.post('/api/products', auth, (req, res) => {
  const { category_id, name, grade, origin, unit, min_price, max_price, certifications } = req.body;
  if (!name || !min_price || !max_price) return res.status(400).json({ error: 'Missing required fields' });
  const result = db.prepare(`INSERT INTO products (category_id, name, grade, origin, unit, min_price, max_price, certifications, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(category_id, name, grade, origin, unit || 'Ton', min_price, max_price, certifications, req.user.id);
  res.json(db.prepare('SELECT * FROM products WHERE id = ?').get(result.lastInsertRowid));
});

app.patch('/api/products/:id', auth, (req, res) => {
  const { name, grade, origin, min_price, max_price, certifications, status } = req.body;
  db.prepare(`UPDATE products SET name=COALESCE(?,name), grade=COALESCE(?,grade), origin=COALESCE(?,origin), min_price=COALESCE(?,min_price), max_price=COALESCE(?,max_price), certifications=COALESCE(?,certifications), status=COALESCE(?,status) WHERE id=?`).run(name, grade, origin, min_price, max_price, certifications, status, req.params.id);
  res.json(db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id));
});

app.delete('/api/products/:id', auth, adminOnly, (req, res) => {
  db.prepare('UPDATE products SET status = ? WHERE id = ?').run('suspended', req.params.id);
  res.json({ ok: true });
});

// ─────────────────────────────────────────────
// ── NEGOTIATIONS ──
// ─────────────────────────────────────────────

app.get('/api/negotiations', auth, (req, res) => {
  const rows = db.prepare('SELECT n.*, p.name as product_name, p.grade FROM negotiations n JOIN products p ON n.product_id = p.id ORDER BY n.created_at DESC').all();
  res.json(rows);
});

app.post('/api/negotiations', auth, (req, res) => {
  const { product_id, quantity, buyer_agent, seller_agent, incoterm, payment_terms } = req.body;
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(product_id);
  if (!product) return res.status(404).json({ error: 'Product not found' });
  const opening_buyer = Math.round(product.min_price * 1.05);
  const opening_seller = product.max_price;
  const result = db.prepare(`INSERT INTO negotiations (product_id, buyer_agent, seller_agent, quantity, opening_buyer, opening_seller, incoterm, payment_terms, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(product_id, buyer_agent || 'BuyerAgent-01', seller_agent || 'SellerAgent-01', quantity || 500, opening_buyer, opening_seller, incoterm || 'FOB', payment_terms || 'LC at sight', req.user.id);
  res.json(db.prepare('SELECT * FROM negotiations WHERE id = ?').get(result.lastInsertRowid));
});

app.patch('/api/negotiations/:id/confirm', auth, (req, res) => {
  const { final_price, rounds } = req.body;
  const neg = db.prepare('SELECT * FROM negotiations WHERE id = ?').get(req.params.id);
  if (!neg) return res.status(404).json({ error: 'Not found' });
  db.prepare('UPDATE negotiations SET final_price=?, rounds=?, status=?, closed_at=datetime("now") WHERE id=?').run(final_price, rounds, 'confirmed', req.params.id);
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(neg.product_id);
  const total = final_price * neg.quantity;
  const fee = Math.round(total * 0.02 * 100) / 100;
  const ref = `CEX-${new Date().getFullYear()}${String(new Date().getMonth()+1).padStart(2,'0')}${String(new Date().getDate()).padStart(2,'0')}-${String(Math.floor(Math.random()*900)+100)}`;
  const dealResult = db.prepare(`INSERT INTO deals (negotiation_id, reference, commodity, grade, quantity, final_price, total_value, incoterm, payment_terms, platform_fee, seller_receives, buyer_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(neg.id, ref, product.name, product.grade, neg.quantity, final_price, total, neg.incoterm, neg.payment_terms, fee, total - fee, req.user.id);
  res.json({ deal: db.prepare('SELECT * FROM deals WHERE id = ?').get(dealResult.lastInsertRowid) });
});

// ─────────────────────────────────────────────
// ── DEALS ──
// ─────────────────────────────────────────────

app.get('/api/deals', auth, (req, res) => {
  const deals = db.prepare('SELECT * FROM deals ORDER BY confirmed_at DESC').all();
  res.json(deals);
});

app.get('/api/deals/:id', auth, (req, res) => {
  const deal = db.prepare('SELECT * FROM deals WHERE id = ? OR reference = ?').get(req.params.id, req.params.id);
  if (!deal) return res.status(404).json({ error: 'Deal not found' });
  res.json(deal);
});

// ─────────────────────────────────────────────
// ── PAYMENTS ──
// ─────────────────────────────────────────────

app.post('/api/payments', auth, (req, res) => {
  const { deal_id, stripe_txn_id, amount, method } = req.body;
  const result = db.prepare('INSERT INTO payments (deal_id, stripe_txn_id, amount, method, status, paid_at) VALUES (?, ?, ?, ?, ?, datetime("now"))').run(deal_id, stripe_txn_id, amount, method || 'card', 'completed');
  db.prepare('UPDATE deals SET status = ? WHERE id = ?').run('paid', deal_id);
  res.json(db.prepare('SELECT * FROM payments WHERE id = ?').get(result.lastInsertRowid));
});

app.get('/api/payments', auth, adminOnly, (req, res) => {
  res.json(db.prepare('SELECT p.*, d.reference, d.commodity FROM payments p JOIN deals d ON p.deal_id = d.id ORDER BY p.created_at DESC').all());
});

// ─────────────────────────────────────────────
// ── USERS (admin) ──
// ─────────────────────────────────────────────

app.get('/api/users', auth, adminOnly, (req, res) => {
  res.json(db.prepare('SELECT id, first_name, last_name, email, company, country, role, kyc_status, is_active, created_at FROM users ORDER BY created_at DESC').all());
});

app.patch('/api/users/:id', auth, adminOnly, (req, res) => {
  const { kyc_status, is_active, role } = req.body;
  db.prepare('UPDATE users SET kyc_status=COALESCE(?,kyc_status), is_active=COALESCE(?,is_active), role=COALESCE(?,role) WHERE id=?').run(kyc_status, is_active, role, req.params.id);
  res.json(db.prepare('SELECT id, first_name, last_name, email, role, kyc_status, is_active FROM users WHERE id = ?').get(req.params.id));
});

// ─────────────────────────────────────────────
// ── STATS (admin dashboard) ──
// ─────────────────────────────────────────────

app.get('/api/stats', auth, adminOnly, (req, res) => {
  const users = db.prepare('SELECT COUNT(*) as total, SUM(CASE WHEN kyc_status="pending" THEN 1 ELSE 0 END) as pending_kyc, SUM(CASE WHEN is_active=0 THEN 1 ELSE 0 END) as suspended FROM users').get();
  const deals = db.prepare('SELECT COUNT(*) as total, SUM(total_value) as volume, SUM(platform_fee) as revenue FROM deals').get();
  const negotiations = db.prepare('SELECT COUNT(*) as active FROM negotiations WHERE status="active"').get();
  const products = db.prepare('SELECT COUNT(*) as total FROM products WHERE status="active"').get();
  res.json({ users, deals, negotiations, products });
});

// ─────────────────────────────────────────────
// ── HEALTH CHECK ──
// ─────────────────────────────────────────────

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', platform: 'CommodEx', version: '1.0.0', timestamp: new Date().toISOString() });
});

// ── START ──
app.listen(PORT, () => console.log(`\n🚀 CommodEx API running on port ${PORT}\n`));
