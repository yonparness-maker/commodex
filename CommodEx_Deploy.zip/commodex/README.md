# CommodEx — AI Trade & Negotiation Platform

AI-powered commodity exchange for Cement, Steel, PP Granules, and Urea.

## Quick Deploy to Railway

1. Fork or upload this repo to GitHub
2. Go to railway.app → New Project → Deploy from GitHub
3. Add environment variable: `JWT_SECRET=your-secret-key`
4. Get your live URL

## Demo Accounts

| Role   | Email                    | Password   |
|--------|--------------------------|------------|
| Buyer  | buyer@commodex.trade     | Demo1234!  |
| Seller | seller@commodex.trade    | Demo1234!  |
| Admin  | admin@commodex.trade     | Demo1234!  |

## Tech Stack

- Backend: Node.js + Express + SQLite (better-sqlite3)
- Auth: JWT + bcrypt
- Frontend: Vanilla HTML/CSS/JS
- Payments: Stripe (frontend wired, add your key)
- Deploy: Railway.app

## Folder Structure

```
commodex/
├── server.js        ← Backend API
├── package.json     ← Dependencies
└── public/
    ├── index.html   ← Login & Register
    ├── platform.html← Exchange & Negotiation
    ├── admin.html   ← Admin Panel
    └── api.js       ← Shared API Client
```

Built with ME-Global Trade Desk · Incoterms 2020 · © 2026
