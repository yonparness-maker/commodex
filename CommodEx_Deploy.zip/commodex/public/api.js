// ─────────────────────────────────────────────
// CommodEx API Client — shared across all pages
// Include in every HTML: <script src="api.js"></script>
// ─────────────────────────────────────────────

window.CEX = (function() {

  // Auto-detect API base URL
  const BASE = window.location.hostname === 'localhost'
    ? 'http://localhost:3000/api'
    : '/api';

  function getToken() { return localStorage.getItem('cex_token'); }
  function getUser()  { try { return JSON.parse(localStorage.getItem('cex_user')); } catch { return null; } }
  function isAdmin()  { var u = getUser(); return u && u.role === 'admin'; }
  function isBuyer()  { var u = getUser(); return u && u.role === 'buyer'; }
  function isSeller() { var u = getUser(); return u && u.role === 'seller'; }

  function headers(json) {
    var h = { 'Authorization': 'Bearer ' + getToken() };
    if (json) h['Content-Type'] = 'application/json';
    return h;
  }

  async function get(path) {
    const r = await fetch(BASE + path, { headers: headers() });
    return r.json();
  }

  async function post(path, body) {
    const r = await fetch(BASE + path, {
      method: 'POST', headers: headers(true), body: JSON.stringify(body)
    });
    return r.json();
  }

  async function patch(path, body) {
    const r = await fetch(BASE + path, {
      method: 'PATCH', headers: headers(true), body: JSON.stringify(body)
    });
    return r.json();
  }

  async function del(path) {
    const r = await fetch(BASE + path, { method: 'DELETE', headers: headers() });
    return r.json();
  }

  // ── AUTH ──
  async function login(email, password) { return post('/auth/login', { email, password }); }
  async function register(data) { return post('/auth/register', data); }
  async function me() { return get('/auth/me'); }

  // ── PRODUCTS ──
  async function getProducts(params) {
    var q = params ? '?' + new URLSearchParams(params).toString() : '';
    return get('/products' + q);
  }
  async function getProduct(id) { return get('/products/' + id); }
  async function createProduct(data) { return post('/products', data); }
  async function updateProduct(id, data) { return patch('/products/' + id, data); }

  // ── CATEGORIES ──
  async function getCategories() { return get('/categories'); }
  async function createCategory(data) { return post('/categories', data); }
  async function updateCategory(id, data) { return patch('/categories/' + id, data); }

  // ── NEGOTIATIONS ──
  async function getNegotiations() { return get('/negotiations'); }
  async function startNegotiation(data) { return post('/negotiations', data); }
  async function confirmNegotiation(id, final_price, rounds) {
    return patch('/negotiations/' + id + '/confirm', { final_price, rounds });
  }

  // ── DEALS ──
  async function getDeals() { return get('/deals'); }
  async function getDeal(id) { return get('/deals/' + id); }

  // ── PAYMENTS ──
  async function recordPayment(deal_id, stripe_txn_id, amount, method) {
    return post('/payments', { deal_id, stripe_txn_id, amount, method });
  }

  // ── USERS (admin) ──
  async function getUsers() { return get('/users'); }
  async function updateUser(id, data) { return patch('/users/' + id, data); }

  // ── STATS (admin) ──
  async function getStats() { return get('/stats'); }

  // ── HEALTH ──
  async function health() { return get('/health'); }

  // ── GUARD: redirect to login if not authenticated ──
  function requireAuth(redirectUrl) {
    if (!getToken()) {
      window.location.href = redirectUrl || 'index.html';
      return false;
    }
    return true;
  }

  function requireAdmin(redirectUrl) {
    if (!isAdmin()) {
      window.location.href = redirectUrl || 'index.html';
      return false;
    }
    return true;
  }

  // ── USER DISPLAY HELPER ──
  function renderUserBadge(containerId) {
    var user = getUser();
    if (!user) return;
    var el = document.getElementById(containerId);
    if (!el) return;
    var colors = { buyer: '#6366f1', seller: '#10b981', admin: '#dc2626' };
    var name = (user.first_name || '') + ' ' + (user.last_name || '');
    var initials = name.split(' ').map(x => x[0]).join('').substring(0, 2) || '??';
    el.innerHTML = '<div style="display:flex;align-items:center;gap:8px">' +
      '<div style="width:28px;height:28px;border-radius:50%;background:' + (colors[user.role] || '#6366f1') + ';display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:700;color:#fff">' + initials + '</div>' +
      '<div><div style="font-size:12px;font-weight:600">' + name.trim() + '</div><div style="font-size:10px;color:#aaa">' + (user.role || '') + ' · ' + (user.company || '') + '</div></div>' +
      '<a href="index.html" style="font-size:11px;color:#aaa;margin-left:8px;text-decoration:none" onclick="localStorage.removeItem(\'cex_token\');localStorage.removeItem(\'cex_user\')">Sign out</a>' +
      '</div>';
  }

  return {
    BASE,
    getToken, getUser, isAdmin, isBuyer, isSeller,
    login, register, me, requireAuth, requireAdmin, renderUserBadge,
    getProducts, getProduct, createProduct, updateProduct,
    getCategories, createCategory, updateCategory,
    getNegotiations, startNegotiation, confirmNegotiation,
    getDeals, getDeal,
    recordPayment,
    getUsers, updateUser,
    getStats, health,
  };
})();
